from openedoo import db
from openedoo import config

db = db

 
