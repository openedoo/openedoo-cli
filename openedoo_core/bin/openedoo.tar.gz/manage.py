from openedoo.core import management
from openedoo import app

if __name__ == '__main__':
    management.execute_cli()
