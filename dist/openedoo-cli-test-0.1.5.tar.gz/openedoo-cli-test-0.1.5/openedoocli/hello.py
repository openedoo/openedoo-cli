import sys

def main():
    print("Hello.")

main = main()