#!/bin/python

from openedoo_core import command
from openedoo_core import app

if __name__ == '__main__':
    command.main()
