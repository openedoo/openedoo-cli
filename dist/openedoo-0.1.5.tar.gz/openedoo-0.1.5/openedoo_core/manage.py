#!/bin/python

from openedoo_cli import command
from openedoo_cli import app

if __name__ == '__main__':
    command.main()
